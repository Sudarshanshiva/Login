package com.example.login

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
